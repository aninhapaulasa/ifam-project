# ifam-tads-padv
Atividade final das disciplinas de Qualidade de software e Projeto Baseado em Componentes - Projeto Assistente de Voz
