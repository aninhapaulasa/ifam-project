## Componente assistente de voz

    Atividade da disciplina Componente de Software

    Objetivo: Criar um componente que transmita em formato de áudio as labels e campos de um formulário.


## Equipe

 - Lucas Viana Torres
 - Victor Duarte Nascimento
 - Ana Paula dos Santos Almada
 - Leanderson da Silva Santos

## Tecnologias

 - Javascript
 - CSS3
 - HTML
 - Bootstrap